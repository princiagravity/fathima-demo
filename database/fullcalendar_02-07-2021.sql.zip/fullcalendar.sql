-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 01:38 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fullcalendar`
--

-- --------------------------------------------------------

--
-- Table structure for table `addon_details`
--

CREATE TABLE `addon_details` (
  `id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `category` varchar(15) NOT NULL,
  `description` varchar(200) NOT NULL,
  `mrp` varchar(15) NOT NULL,
  `price` varchar(15) NOT NULL,
  `max_sale` varchar(15) NOT NULL,
  `image_url` varchar(150) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addon_details`
--

INSERT INTO `addon_details` (`id`, `name`, `category`, `description`, `mrp`, `price`, `max_sale`, `image_url`, `status`, `created_on`, `updated_on`) VALUES
(1, 'chapati', '2', 'asasasas', '15', '10', '9', 'http://localhost/new_admin/uploads/addon-images/ADDON_16251393287.jpg', 'In Stock', '2021-07-01 17:05:28', '2021-07-02 16:50:32'),
(2, 'porotta', '2', 'porotta', '20', '20', '20', 'http://localhost/new_admin/uploads/addon-images/ADDON_16251988464.jpg', 'In Stock', '2021-07-02 09:37:26', '2021-07-02 16:50:41');

-- --------------------------------------------------------

--
-- Table structure for table `area_master`
--

CREATE TABLE `area_master` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area_master`
--

INSERT INTO `area_master` (`id`, `name`, `status`, `created_on`, `updated_on`) VALUES
(1, 'Irinjalakuda', 'Active', '2021-07-02 11:49:41', '2021-07-02 15:45:29'),
(2, 'Mapranam', 'Active', '2021-07-02 11:50:00', '2021-07-02 15:45:29'),
(3, 'Kodungallur', 'Active', '2021-07-02 11:50:07', '2021-07-02 15:45:29'),
(4, 'Mundur', 'Active', '2021-07-02 11:50:12', '2021-07-02 15:45:29'),
(5, 'Pullur', 'Active', '2021-07-02 11:50:17', '2021-07-02 15:45:29');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `image_url` varchar(200) NOT NULL,
  `type` varchar(25) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`id`, `name`, `image_url`, `type`, `status`, `created_on`, `updated_on`) VALUES
(1, 'bhiryani', 'http://localhost/new_admin/uploads/category-images/CATEGORY_16251313957.jpg', 'product', 'Active', '2021-07-01 14:53:15', '2021-07-02 15:46:12'),
(2, 'snacks', 'http://localhost/new_admin/uploads/category-images/CATEGORY_16251315168.jpg', 'product', 'Active', '2021-07-01 14:55:16', '2021-07-02 15:46:12'),
(3, 'Ice Cream', 'http://localhost/new_admin/uploads/category-images/CATEGORY_16251987337.jpg', 'product', 'Active', '2021-07-02 09:35:33', '2021-07-02 15:46:12'),
(5, 'Juices', 'http://localhost/new_admin/uploads/category-images/CATEGORY_16252041726.jpg', 'product', 'Active', '2021-07-02 11:06:12', '2021-07-02 15:46:12'),
(6, 'Percentage', 'http://localhost/new_admin/uploads/category-images/', 'promocode', 'Active', '2021-07-02 11:07:32', '2021-07-02 15:46:12'),
(7, 'Total Cart Value', 'http://localhost/new_admin/uploads/category-images/', 'promocode', 'Active', '2021-07-02 11:08:27', '2021-07-02 15:46:12');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_charge_master`
--

CREATE TABLE `delivery_charge_master` (
  `id` int(11) NOT NULL,
  `area` varchar(50) NOT NULL,
  `charge` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery_charge_master`
--

INSERT INTO `delivery_charge_master` (`id`, `area`, `charge`, `status`, `created_on`, `updated_on`) VALUES
(1, '1', 50, 'Active', '2021-07-02 12:03:10', '2021-07-02 15:47:23');

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `category` varchar(10) NOT NULL,
  `description` varchar(300) NOT NULL,
  `variants` varchar(35) NOT NULL,
  `mrp` varchar(15) NOT NULL,
  `price` varchar(15) NOT NULL,
  `max_sale` varchar(15) NOT NULL,
  `image_url` varchar(150) NOT NULL,
  `status` varchar(25) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`id`, `name`, `category`, `description`, `variants`, `mrp`, `price`, `max_sale`, `image_url`, `status`, `created_on`, `updated_on`) VALUES
(1, 'thalassery', '1', 'sada', '1', '150', '140', '135', 'http://localhost/new_admin/uploads/product-images/PROD_16251375641.png', 'In Stock', '2021-07-01 16:36:04', '2021-07-02 15:48:47'),
(2, 'shawarma', '2', 'shawarma', '1', '200', '210', '210', 'http://localhost/new_admin/uploads/product-images/PROD_16251986062.jpg', 'In Stock', '2021-07-02 09:33:26', '2021-07-02 15:48:47');

-- --------------------------------------------------------

--
-- Table structure for table `promocode_details`
--

CREATE TABLE `promocode_details` (
  `id` int(11) NOT NULL,
  `promo_code` varchar(150) NOT NULL,
  `category` varchar(40) NOT NULL,
  `no_of_usage` varchar(15) NOT NULL,
  `min_order` varchar(15) NOT NULL,
  `max_discount` varchar(15) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `promocode_details`
--

INSERT INTO `promocode_details` (`id`, `promo_code`, `category`, `no_of_usage`, `min_order`, `max_discount`, `status`, `created_on`, `updated_on`) VALUES
(1, '123455', '7', '10', '1000', '50', 'Active', '2021-07-02 11:36:23', '2021-07-02 15:47:45');

-- --------------------------------------------------------

--
-- Table structure for table `slider_details`
--

CREATE TABLE `slider_details` (
  `id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `link` varchar(150) NOT NULL,
  `image_url` varchar(250) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider_details`
--

INSERT INTO `slider_details` (`id`, `name`, `link`, `image_url`, `created_on`, `updated_on`, `status`) VALUES
(3, 'dssad', 'cxzczxc', 'http://localhost/new_admin/uploads/slider-images/SLIDER_16251247087', '2021-07-01 13:01:48', '2021-07-02 16:00:08', 'Active'),
(4, 'dssad', 'cxzczxc', 'http://localhost/new_admin/uploads/slider-images/SLIDER_16251249797.png', '2021-07-01 13:06:19', '2021-07-02 16:00:08', 'Active'),
(5, 'xcxzcz', 'dasdasd', 'http://localhost/new_admin/uploads/slider-images/SLIDER_16251252262.jpg', '2021-07-01 13:10:26', '2021-07-02 16:00:08', 'Active'),
(6, 'xcxzcz', 'dasdasd', 'http://localhost/new_admin/uploads/slider-images/SLIDER_16251306639.jpg', '2021-07-01 14:41:03', '2021-07-02 16:00:08', 'Active'),
(7, 'aaaaa', 'aaaa', 'http://localhost/new_admin/uploads/slider-images/SLIDER_16251308391.png', '2021-07-01 14:43:59', '2021-07-02 16:00:08', 'Active'),
(8, 'slider12', 'slider12', 'http://localhost/new_admin/uploads/slider-images/SLIDER_16251986612.jpg', '2021-07-02 09:34:21', '2021-07-02 16:00:08', 'Active'),
(9, 'abc', 'abc.html', 'http://localhost/new_admin/uploads/slider-images/SLIDER_16252170209.jpg', '2021-07-02 14:40:20', '2021-07-02 16:00:08', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `variants_master`
--

CREATE TABLE `variants_master` (
  `id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `variants_master`
--

INSERT INTO `variants_master` (`id`, `name`, `status`, `created_on`, `updated_on`) VALUES
(1, 'full', 'Active', '2021-07-01 15:02:14', '2021-07-02 15:48:07'),
(2, 'half', 'Active', '2021-07-01 15:05:05', '2021-07-02 15:48:07'),
(3, 'Quarter', 'Active', '2021-07-01 15:05:13', '2021-07-02 15:48:07'),
(4, '100ml', 'Active', '2021-07-02 09:36:23', '2021-07-02 15:48:07'),
(5, '500ml', 'Active', '2021-07-02 15:44:19', '2021-07-02 15:44:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addon_details`
--
ALTER TABLE `addon_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `area_master`
--
ALTER TABLE `area_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_charge_master`
--
ALTER TABLE `delivery_charge_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `promocode_details`
--
ALTER TABLE `promocode_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider_details`
--
ALTER TABLE `slider_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `variants_master`
--
ALTER TABLE `variants_master`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addon_details`
--
ALTER TABLE `addon_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `area_master`
--
ALTER TABLE `area_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `delivery_charge_master`
--
ALTER TABLE `delivery_charge_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `promocode_details`
--
ALTER TABLE `promocode_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slider_details`
--
ALTER TABLE `slider_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `variants_master`
--
ALTER TABLE `variants_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
